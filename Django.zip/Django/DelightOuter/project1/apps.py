from django.apps import AppConfig


class Project1Config(AppConfig):
    name = 'project1'
